
#include "Repository.h"
#include "Table.h"
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;

void Repository::read_from_file() {
    string line;
    ifstream myfile("input.txt");
    while (true) {
        if (myfile.eof()) {
            break;
        }
        Table pg;

        try {
            myfile >> pg;
            this->tb = pg;
        }
        catch (...) {

        }

    }
    myfile.close();
}

const Table &Repository::getTb() const {
    return tb;
}

void Repository::place_mine(int col, int row) {
    tb.place_mine(col, row);
}
