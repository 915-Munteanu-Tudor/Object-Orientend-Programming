
#ifndef RETAKE_EXAM_REPOSITORY_H
#define RETAKE_EXAM_REPOSITORY_H


#include "Table.h"

class Repository {
private:
    Table tb;
public:
    const Table &getTb() const;

public:
    void read_from_file();
    void place_mine(int col, int row);
};


#endif //RETAKE_EXAM_REPOSITORY_H
