
#include "Table.h"

Table::Table(int dim, int mines, int turn, const vector<string> &names) : dim(dim), mines(mines), turn(turn),
                                                                          names(names) {}
std::istream &operator>>(istream &is, Table &p) {
    string size;

    std::getline(is,size);
    p.setDim(stoi(size));
    string mines;
    std::getline(is,mines);
    p.setMines(stoi(mines));
    p.setTurn(0);
    string newl;
    std::getline(is, newl);
    std::vector<string> names;
    while(!newl.empty()){
        names.push_back(newl);
        newl.clear();
        std::getline(is, newl);
    }
    p.setNames(names);
    for(int i = 0; i < p.getDim() * p.getDim(); i++) {
        p.dangers.push_back(0);
    }
    for(int i = 0; i < p.getDim() * p.getDim(); i++) {
        p.revealed.push_back(0);
    }
    int i = 0;
    while(i < p.getMines()) {
        while(true){
            int n = rand() % (p.getDim() * p.getDim());
            if(p.dangers[n] == 0){
                p.dangers[n] = 1;
                break;
            }
        }
        i++;
    }
    return is;
}

int Table::getDim() const {
    return dim;
}

void Table::setDim(int dim) {
    Table::dim = dim;
}

int Table::getMines() const {
    return mines;
}

void Table::setMines(int mines) {
    Table::mines = mines;
}

int Table::getTurn() const {
    return turn;
}

void Table::setTurn(int turn) {
    Table::turn = turn;
}

const vector<string> &Table::getNames() const {
    return names;
}

void Table::setNames(const vector<string> &names) {
    Table::names = names;
}

const vector<int> &Table::getDangers() const {
    return dangers;
}

const vector<int> &Table::getRevealed() const {
    return revealed;
}

void Table::place_mine(int col, int row) {
    revealed[row*dim+col] = 1;
}

