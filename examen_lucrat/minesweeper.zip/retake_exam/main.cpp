#include <iostream>
#include <QApplication>
#include "Repository.h"
#include "Service.h"
#include "GUIObserver.h"

int main(int argc, char** argv) {
    srand(time(0));
    QApplication a(argc, argv);

    Repository r;
    r.read_from_file();
    Service s{r};
    ProduseGUI gui{ s };
    gui.show();
    return a.exec();
}
