#pragma once

#include <QAbstractTableModel>
#include "Table.h"
#include "QBrush"
using std::vector;

class MyTableModel:public QAbstractTableModel{
private:
    vector<int> tb;
    int dim;
public:
    MyTableModel() {};

    MyTableModel(const std::vector<int>& tb, int dim) : tb{tb}, dim{dim}{};

    int columnCount(const QModelIndex& parent = QModelIndex()) const override {
        return dim;
    }
    int rowCount(const QModelIndex& parent = QModelIndex()) const override {
        return dim;
    }

    void setNumbers(const std::vector<int>& tb, int dim) {
        this->dim = dim;
        this->tb = tb;
        QModelIndex topLeft = createIndex(0, 0);
        QModelIndex bottomRight = createIndex(rowCount(), columnCount());
        emit dataChanged(topLeft, bottomRight);
        emit layoutChanged();
    }

    QVariant data(const QModelIndex& index, int role) const override {
        if (role == Qt::BackgroundRole) {
            int p = tb[index.row()*dim + index.column()];
            if(p == 0)
              return QBrush{Qt::green};
            if(p == 1)
                return QBrush{Qt::red};
        }
        if (role == Qt::DisplayRole) {
            int p = tb[index.row()*dim + index.column()];
            if(p == 0)
                return QString::fromStdString("");
            else if (p == 1){
                return QString::fromStdString("*");
            }
        }
        return QVariant{};
    }
};
