#pragma once

#include <QtWidgets/QMainWindow>
#include "Table.h"
#include "Service.h"
#include "MyTableModel.h"

#include <qtablewidget.h>
#include <QHeaderView>
#include <qstandarditemmodel.h>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLineEdit>
#include <QFormLayout>
#include <QMessageBox>
#include <QLabel>
#include <QFormLayout>

#include <vector>
#include <algorithm>


using std::vector;

class Observer {
public:
    virtual void update() = 0;
};

class FereastraPlayer : public Observer, QWidget
{
public:
    void notifyObservers() {
        for (auto& o : observers) {
            o->update();
        }
    }
    Service& serv;
    vector <Observer*>& observers;
    string player;
    int turn = -1;
    int nr;
    int max_nr;

    QTableView* tblView = new QTableView();
    MyTableModel* tbl = new MyTableModel();
    QLineEdit* coord = new QLineEdit();
    QPushButton* reveal = new QPushButton("Reveal");
    QPushButton* mark_mine = new QPushButton("Mark mine");

    FereastraPlayer(Service& serv, vector<Observer*>& observers, string tip, int nr, int max_nr) : max_nr{max_nr}, serv{ serv }, observers{ observers }, player{tip}, nr{nr}{
        loadData(serv.getAll());
        initGUI();
        update();
        initConnect();
    };

    void initConnect(){
        QObject::connect(mark_mine, &QPushButton::clicked, [&](){
            std::string txt = coord->text().toStdString();
            if(txt.size()!= 2){
                QMessageBox::critical(this, "critical", QString::fromStdString("Wrong coordinates!"));
                return;
            }
            if(!(txt[1]-'0'>=0 && txt[1]<serv.getDim()+'0') || !(txt[0]-'A'>=0 && txt[0]<'A'+serv.getDim())){
                QMessageBox::critical(this, "critical", QString::fromStdString("Wrong coordinates!"));
                return;
            }
            if(serv.getAll()[(txt[0]-'A')*serv.getDim()+(txt[1]-'0')] != 0){
                QMessageBox::critical(this, "critical", QString::fromStdString("Already revealed!"));
                return;
            }
            else {
                serv.place_mine(txt[1]-'0', txt[0]-'A');
                notifyObservers();
            }
        });
    }
    void loadData(const vector<int>& numbers) {
        tbl->setNumbers(numbers, serv.getDim());
    }
    void initGUI() {

        this->setWindowTitle(QString::fromStdString(player));

        QHBoxLayout* lyMain = new QHBoxLayout{};
        setLayout(lyMain);

        QVBoxLayout* lyLeft = new QVBoxLayout{};
        tblView->setModel(tbl);
        tblView->horizontalHeader()->setDefaultSectionSize(50);
        tblView->verticalHeader()->setDefaultSectionSize(50);
        lyLeft->addWidget(tblView);
        lyMain->addLayout(lyLeft);
        coord->setPlaceholderText("coordinates");
        lyLeft->addWidget(coord);
        lyLeft->addWidget(reveal);
        lyLeft->addWidget(mark_mine);
        if(turn != nr){
            reveal->setDisabled(true);
            mark_mine->setDisabled(true);
        }
        this->show();
    }
    void update() override{
        loadData(serv.getAll());
        if(turn == max_nr-1)
            turn = 0;
        else
            turn++;
        if(turn == nr){
            reveal->setDisabled(false);
            mark_mine->setDisabled(false);
        }
        else {
            reveal->setDisabled(true);
            mark_mine->setDisabled(true);
        }
    }
};

class ProduseGUI : public QWidget
{
    void addObserver(Observer* obs) {
        observers.push_back(obs);
    }

    void notifyObservers() {
        for (auto& o : observers) {
            o->update();
        }
    }

private:
    vector <Observer*> observers;

    Service& serv;
    QTableView* tblView = new QTableView();
    MyTableModel* tbl = new MyTableModel();


    void loadData(const vector<int>& numbers) {
        tbl->setNumbers(numbers, serv.getDim());
    }

    void initGUI() {
        auto playeri = serv.getPlayers();
        int nr = 0;
        int max_nr = serv.getPlayers().size();
        for (auto player : playeri) {
                addObserver(new FereastraPlayer{ serv,observers, player , nr, max_nr});
                nr++;
        }

        QHBoxLayout* lyMain = new QHBoxLayout{};
        setLayout(lyMain);

        QVBoxLayout* lyLeft = new QVBoxLayout{};
        tblView->setModel(tbl);
        tblView->horizontalHeader()->setDefaultSectionSize(50);
        tblView->verticalHeader()->setDefaultSectionSize(50);
        lyLeft->addWidget(tblView);
        lyMain->addLayout(lyLeft);

    }

    void initConnect() {


    }
public:
    ProduseGUI(Service& serv) : serv{ serv } {
        loadData(serv.getAll());
        initGUI();
        initConnect();
    };

};