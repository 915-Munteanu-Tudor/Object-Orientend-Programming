
#ifndef RETAKE_EXAM_SERVICE_H
#define RETAKE_EXAM_SERVICE_H


#include "Repository.h"

class Service {
public:
    Service(Repository &r);
    vector<int>& getAll();
    int getDim();
    vector<string>& getPlayers();
    void place_mine(int col, int row);
private:
    Repository& r;
};


#endif //RETAKE_EXAM_SERVICE_H
