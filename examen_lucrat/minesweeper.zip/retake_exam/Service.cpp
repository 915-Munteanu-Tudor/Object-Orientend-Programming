
#include "Service.h"

Service::Service(Repository &r) : r(r) {}

vector<int> &Service::getAll() {
    return const_cast<vector<int> &>(r.getTb().getRevealed());
}

int Service::getDim() {
    return r.getTb().getDim();
}

vector<string> &Service::getPlayers(){
    return const_cast<vector<std::string> &>(r.getTb().getNames());
}

void Service::place_mine(int col, int row) {
    r.place_mine(col, row);
}
