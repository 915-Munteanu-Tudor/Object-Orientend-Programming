
#ifndef RETAKE_EXAM_TABLE_H
#define RETAKE_EXAM_TABLE_H


#include <vector>
using namespace std;
#include <string>
#include <fstream>
class Table {
public:
    Table(int dim, int mines, int turn, const vector<string> &names);
    Table() = default;
    friend std::istream &operator>>(std::istream &is, Table &pg);

    int getDim() const;

    void setDim(int dim);

    int getMines() const;

    void setMines(int mines);

    int getTurn() const;

    void setTurn(int turn);

    const vector<string> &getNames() const;

    void setNames(const vector<string> &names);


private:
    int dim;
    int mines;
    int turn;
    std::vector<string> names;
    std::vector<int> dangers;
    std::vector<int> revealed;
public:
    const vector<int>& getRevealed() const;

public:
    const vector<int> &getDangers() const;

public:
    void place_mine(int col, int row);

};


#endif //RETAKE_EXAM_TABLE_H
